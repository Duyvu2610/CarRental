interface BrandPullDown {
    id: number;
    name: string;
}

export default BrandPullDown;