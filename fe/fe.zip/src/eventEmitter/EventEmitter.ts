// eventEmitter.js
import EventEmitter from 'eventemitter3';
export const Emitter = new EventEmitter();