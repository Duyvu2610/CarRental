const routes = {
  home: "/",
  login: "/login",
  signup: "/signup",
  product: "/products",
  contact: "/contact",
  live: "/live",
  cart: "/cart",
  stream: "/live/stream",
  thank: "/thank",
  about: "/about",
  account: "/account",
  car: "/car",
  carregistermodel: "/car/register-model",
  selfdrive: "/car/self-drive",
  "forgot-pass": "/forgot-password",
  "reset-pass": "/reset-password",
  "produc-detail": "/products/:id",
  "page-not-found": "*",
};

export default routes;
